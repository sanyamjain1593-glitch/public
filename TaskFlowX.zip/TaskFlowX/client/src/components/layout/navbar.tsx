import { Button } from "@/components/ui/button";

interface NavbarProps {
  currentView: "kanban" | "history";
  onViewChange: (view: "kanban" | "history") => void;
  onToggleThemeSelector: () => void;
}

export function Navbar({ currentView, onViewChange, onToggleThemeSelector }: NavbarProps) {
  return (
    <nav className="navbar-glass sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <i className="fas fa-rocket text-background text-lg"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">FutureBoard</h1>
              <p className="text-xs text-muted-foreground">AI-Powered Productivity</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant={currentView === "kanban" ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewChange("kanban")}
              data-testid="button-switch-kanban"
            >
              <i className="fas fa-columns mr-2"></i>Board
            </Button>
            <Button
              variant={currentView === "history" ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewChange("history")}
              data-testid="button-switch-history"
            >
              <i className="fas fa-history mr-2"></i>History
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleThemeSelector}
              data-testid="button-toggle-theme"
            >
              <i className="fas fa-palette"></i>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
