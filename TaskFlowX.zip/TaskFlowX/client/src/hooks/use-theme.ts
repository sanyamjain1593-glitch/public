import { createContext, useContext, useState, useEffect, createElement } from "react";
import type { ReactNode } from "react";
import { themes } from "@/lib/themes";

interface ThemeContextType {
  currentTheme: string;
  setTheme: (themeId: string) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [currentTheme, setCurrentTheme] = useState("nebula-purple");

  useEffect(() => {
    const savedTheme = localStorage.getItem("futureBoard-theme");
    if (savedTheme && themes.find(t => t.id === savedTheme)) {
      setCurrentTheme(savedTheme);
    }
  }, []);

  useEffect(() => {
    const theme = themes.find(t => t.id === currentTheme);
    if (theme) {
      const root = document.documentElement;
      document.body.style.background = theme.gradient;
      root.style.setProperty("--theme-primary", theme.primary);
      root.style.setProperty("--theme-secondary", theme.secondary);
      root.style.setProperty("--theme-accent", theme.accent);
      localStorage.setItem("futureBoard-theme", currentTheme);
    }
  }, [currentTheme]);

  const setTheme = (themeId: string) => {
    setCurrentTheme(themeId);
  };

  const value = { currentTheme, setTheme };
  
  return createElement(ThemeContext.Provider, { value }, children);
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
}